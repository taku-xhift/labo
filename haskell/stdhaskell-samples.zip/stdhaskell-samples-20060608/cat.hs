main = do cs <- getContents
          putStr cs
