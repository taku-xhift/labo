import List

main = putStr . unlines . sort . lines =<< getContents
