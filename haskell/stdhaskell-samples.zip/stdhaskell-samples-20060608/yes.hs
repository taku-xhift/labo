main :: IO ()
main = putStrLn "y" >> main
