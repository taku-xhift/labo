import System

main = do args <- getArgs
          putStrLn $ unwords args
