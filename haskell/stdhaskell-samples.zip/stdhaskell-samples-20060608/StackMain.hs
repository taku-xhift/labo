import Stack

main = print . top . pop . push 3 . push 2 . push 1 $ emptyStack
