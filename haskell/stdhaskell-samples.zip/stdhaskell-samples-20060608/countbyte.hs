main = do cs <- getContents
          print $ length cs
