main = print . length . lines =<< getContents
