main = getContents >>= putStr
